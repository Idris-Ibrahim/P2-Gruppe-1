const Sequelize = require("sequelize");
const {Datatypes, Op} = Sequelize;
const Main = require("../models/users");

